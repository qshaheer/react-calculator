import React from 'react';
import './App.css';
import Calculate from './components/Calculate';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Calculate/>
      </header>
    </div>
  );
}

export default App;
