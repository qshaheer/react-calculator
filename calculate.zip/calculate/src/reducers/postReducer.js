import axios from 'axios';
const postReducer = (state = [], action) => {
    switch(action.type) {
      case 'ADD_POST':
        axios.post('http://localhost:4000/',action.data)
                .then(res => console.log(res.data));
        return state.concat([action.data]);
      default:
        return state;
    }
  }
  export default postReducer;