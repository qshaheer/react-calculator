import React from "react";
import { connect } from "react-redux";

class Calculate extends React.Component {
  handleSubmit = e => {
    e.preventDefault();
    const num1 = parseInt(this.getNum1.value);
    const num2 = parseInt(this.getNum2.value);
    const selectValue = this.getOp.value;

    if (selectValue === "+") {
      const result = num1 + num2;
      const data = {
        num1,
        num2,
        result
      };
      console.log(data);
      this.props.dispatch({
        type: "ADD_POST",
        data
      });
    }
    if (selectValue === "-") {
      const result = num1 - num2;
      const data = {
        num1,
        num2,
        result
      };
      console.log(data);
      this.props.dispatch({
        type: "ADD_POST",
        data
      });
    }
    if (selectValue === "/") {
      const result = num1 / num2;
      const data = {
        num1,
        num2,
        result
      };
      console.log(data);
      this.props.dispatch({
        type: "ADD_POST",
        data
      });
    }
  };

  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <input type="number" ref={input => (this.getNum1 = input)} />
        <br />
        <select ref={input => (this.getOp = input)}>
          <option>+</option>
          <option>-</option>
          <option>/</option>
        </select>
        <br />
        <input type="number" ref={input => (this.getNum2 = input)} />
        <br />
        <input type="submit" />
        <br />
        
        <div>
          <h1 className="post_heading">All Results</h1>
          {this.props.posts.map(post => (
            <div key={post.id}>{post.result}</div>
          ))}
        </div>
      </form>
    );
  }
}
const mapStateToProps = state => {
  return {
    posts: state
  };
};


export default connect(mapStateToProps)(Calculate);
