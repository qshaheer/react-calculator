import axios from 'axios';

export const createPostSuccess =  (data) => {
    return {
      type: 'ADD_POST',
      payload: {
        num1: data.num1,
        num2: data.num2,
        result: data.result
      }
    }
  };
export const createPost = ({ num1, num2, result }) => {
    return (dispatch) => {
      return axios.post('http://localhost:4000/', {num1, num2, result})
        .then(response => {
          dispatch(createPostSuccess(response.data))
        })
        .catch(error => {
          throw(error);
        });
    };
  };