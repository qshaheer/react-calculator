import React from 'react';
import logo from './logo.svg';
import Products from './components/Products';
import Homepage from './components/Homepage';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import './App.css';

const App = () => {
  return (
    <>
      <Router>
        <Switch>
          <Route exact path="/" component={Homepage} />
          <Route exact path="/products" component={Products} />
        </Switch>
      </Router>
      </>
  );
}

export default App;
