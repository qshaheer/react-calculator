import React, { Component } from 'react';
import { Button } from  '@material-ui/core';
import CssBaseline from '@material-ui/core/CssBaseline';
import Typography from '@material-ui/core/Typography';
import Container from '@material-ui/core/Container';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
const styles = theme => ({
    root: {
      marginTop: theme.spacing.unit *3,
      width: '100%'
    },
    flex: {
      flex: 1
    },
    menuButton: {
      marginLeft: -12,
      marginRight: 20
    },
    nav: {
      paddingLeft: 90
    }
  })
class Homepage extends Component {
    render() {
        return (
            <div>

            <React.Fragment>
                <CssBaseline />
                <AppBar position="static" elevation={0}>
                <Toolbar>
                <IconButton className={styles.menuButton} color="contrast" onClick={this.props.toggleDrawer}></IconButton>
                <Typography className={styles.flex} type="title" color="inherit">
                    Router99
                </Typography>
                    {/* <IconButton color="contrast">
                    </IconButton>
                    <img src="workplace.jpg" alt="Workplace" usemap="#workmap" width="90" height="19"/>
                <a href="/products">
                    PRODUCTS
                </a> */}
                <div className={styles.nav}>
                  <Button ><a href="#">SHOW PRODUCTS</a></Button>
                </div>

                </Toolbar>
                </AppBar>
                <Container>

                </Container>
              </React.Fragment>

 
            </div>
        );
    }
}

export default Homepage;