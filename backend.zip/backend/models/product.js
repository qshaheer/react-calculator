// product.js file (server/models/product.js)

let mongoose = require('mongoose');
let Schema = mongoose.Schema;

var Product = new Schema(
  {
    name: {
      type: String,
      required: [true, "product name is required"],
    },
    category: [
      {
        type: mongoose.Schema.ObjectId,
        ref: "Category",
        required: [true, "category is required"],
      },
    ],
    price: {
        type: Number,
        required: [true, "price is required"],
      },
    description: {
      type: String,
      required: [true, "description is required"],
    },
    imagePath: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('Product', Product);