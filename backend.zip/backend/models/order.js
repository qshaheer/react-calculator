// product.js file (server/models/product.js)

let mongoose = require('mongoose');
let Schema = mongoose.Schema;

var Order = new Schema(
  {
    name: {
      type: String,
      required: true,
    },
    products: [
      {
        type: Array,
        ref: "Product",
        required: true,
      },
    ],
    price: {
      type: Number,
      required: true,
    },
    discount: {
        type: Number,
        required: false,
      },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('Order', Order);