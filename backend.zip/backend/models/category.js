const mongoose = require('mongoose');
let Schema = mongoose.Schema;

const Category = new Schema({
    name: {
      type: String,
      required: [true, "category name is required"],
    }
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('Category', Category);