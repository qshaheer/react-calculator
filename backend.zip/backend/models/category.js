const mongoose = require('mongoose');

const Category = mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "category name is required"],
    }
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('Category', Category);