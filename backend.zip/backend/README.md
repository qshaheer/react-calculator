# E-Commerce Store with MERN Stack

This app is the follow up of my boilerplate-MERN:
https://github.com/khoadodk/boilerplate-mern-stack

# App features

<ul>
<li>Login/Signup system</li>
<li>User/Admin dashBoard</li>
<li>Products filtered by category or price</li>
<li>Product Search</li>
<li>Product page with related products</li>
<li>Shopping cart</li>
<li>Payment with Credit Card or PayPal</li>
<li>Email notification when an order is placed</li>
</ul>
