const express = require('express');
const categoryService = require('../../../services/v2/categories/categories');
const validation = require('../../../middlewares/categoryValidation');
// const authClientRequest = require('../../../middlewares/authGaurd');
let router = express.Router();

router.get('/:categoryId', categoryService.getCategoryDetails);
router.get('/', categoryService.getAllCategories);
router.post('/add', validation.validateAddCategoryBody, categoryService.addCategory);

module.exports = router;