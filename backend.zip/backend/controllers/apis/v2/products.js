const express = require('express');
const productService = require('../../../services/v2/products/products');
const validation = require('../../../middlewares/validation');
let router = express.Router();
const multer = require('multer');
const fs = require('fs');
var csvStorage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, "./uploads/products/csv");
  },
  filename: function (req, file, callback) {
    callback(null, file.fieldname + "-" + Date.now());
  },
});
var imgStorage = multer.diskStorage({
  destination: function (req, file, callback) {
    const { name } = req.body;
    const path = `./uploads/products/images/${name}`;
    if (!fs.existsSync(path)){
      fs.mkdirSync(path);
    }
    console.log("==@@@***req multer***@@@====", path);
    callback(null, path);
  },
  filename: function (req, file, callback) {
    callback(null, file.fieldname + "-" + Date.now());
  },
});
const imgFilter = (req, file, cb) => {
  if (
    file.mimetype === "image/jpg" ||
    file.mimetype === "image/jpeg" ||
    file.mimetype === "image/png"
  ) {
    cb(null, true);
  } else {
    cb(new Error("Image uploaded is not of type jpg/jpeg or png"), false);
  }
};

const csvFilter = (req, file, cb) => {
  if (
    file.mimetype === "text/csv" 
  ) {
    cb(null, true);
  } else {
    cb(new Error("File uploaded is not of type csv"), false);
  }
};

const imgUpload = multer({ storage : imgStorage, fileFilter : imgFilter});
const csvUpload = multer({ storage : csvStorage, fileFilter : csvFilter});

router.get('/:productId', productService.getProductDetails);
router.get('/', productService.getAllProducts);
router.post('/add', imgUpload.array('img',3), productService.addProduct);
router.post('/add_product_from_file', csvUpload.single('csv') , productService.addProductFromFile);

module.exports = router;