const express = require('express');
const productService = require('../../../services/v2/products/products');
const validation = require('../../../middlewares/productValidation');
// const authClientRequest = require('../../../middlewares/authGaurd');
let router = express.Router();

router.get('/:productId', productService.getProductDetails);
router.get('/', productService.getAllProducts);
router.post('/add', validation.validateAddProductBody, productService.addProduct);

module.exports = router;