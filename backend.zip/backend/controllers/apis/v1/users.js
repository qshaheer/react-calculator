const express = require('express');
const userService = require('../../../services/v1/users/users');
const authClientRequest = require('../../../middlewares/authGaurd');
import { authenticateRoute } from '../../../middlewares/authGaurd';
import { checkRole, ROLES } from '../../../middlewares/checkRoles';
const passport = require('passport');
let router = express.Router();

router.get('/findUser', /*authClientRequest.authClientToken,*/ (req,res) => {
    passport.authenticate('jwt', { session: false }, (err, user, info) => {
        // console.log('Find User: ', { err, user, info });
    
        if (err || !user) {
          return res.status(400).send(err && err.message);
        }
    
        return res.json({ user });
      })(req, res)
} , userService.getUserDetails);
router.get('/', authClientRequest.authClientToken, /*authClientRequest.grantAccess('readAny', 'profile')*/userService.getAllUsers);

module.exports = router;