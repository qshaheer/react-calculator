const express = require('express');
// const multer = require('multer');
const authService = require('../../../services/v1/auth/auth');
const validation = require('../../../middlewares/validation');
let router = express.Router();
const multer = require('multer');

var storage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, "./uploads/users");
  },
  filename: function (req, file, callback) {
    callback(null, file.fieldname + "-" + Date.now());
  },
});
const fileFilter = (req, file, cb) => {
  if (
    file.mimetype === "image/jpg" ||
    file.mimetype === "image/jpeg" ||
    file.mimetype === "image/png"
  ) {
    cb(null, true);
  } else {
    cb(new Error("Image uploaded is not of type jpg/jpeg or png"), false);
  }
};
const upload = multer({ storage : storage, fileFilter : fileFilter});
// router.post('/register', upload.single('image'), validation.validateRegistrationBody(), authService.register);

router.post('/register', upload.single('img'), validation.validateRegistrationBody(), authService.register);
router.post('/login', authService.login);

module.exports = router;