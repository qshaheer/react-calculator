const { body } = require('express-validator/check')

const validateAddProductBody = () => {
    return [ 
        body('name')
        .exists()
        .withMessage('name field is required')
        .isLength({min:3})
        .withMessage('name must be greater than 3 letters'),
        body('category').exists()
        .withMessage('category field is required'),
        body('price')
        .exists()
        .withMessage('price field is required'),
        body('description')
        .exists()
        .withMessage('description field is required')
        .isLength({min:5})
        .withMessage('description must be greater than 5 letters'),
       ] 
} 

module.exports = {
    validateAddProductBody : validateAddProductBody
}