const express = require('express');
const jwt = require('jsonwebtoken');
const passport = require('passport');
const config = require('../config/env_config/config');
const { roles } = require('../middlewares/roles');
const userModel = require('../models/user');
var expressJwt = require('express-jwt');
const _ = require('lodash');

const authClientToken = async (req,res,next) => {

    let token = req.headers['Authorization'];
    
    if (!token){
        return res.status(401).json({
            "errors" : [{
                "msg" : " No token provided"
            }]
        });
    } 
    await jwt.verify(token,'secret1', (err,decoded) => {
        if(err){
            return res.status(401).json({
                "errors" : [{
                    "msg" : "Invalid Token"
                }]
            });
        }
        return next();
    });
}

const authenticateRoute = (request, response, next) => {
  // const authenticationWhiteList = [
  //   'GET /api/v2/products', 'GET /api/v2/products/'
  // ];

  // let route = `${request.method} ${request.originalUrl}`
  // console.log("====inside authenticateRute===*", route, "*====");
  // // console.log("=====**req.user**=======", request.user);
  // if (_.indexOf(authenticationWhiteList, route) !== -1) {
  //   next();
  // } else {
    passport.authenticate('jwt', { session: false })(request, response, next);
  // }
}

const requireSignin = (req,res,next) => {
   expressJwt({
    // secret: process.env.JWT_SECRET,
    secret: 'secret1',
    userProperty: 'auth',
    algorithms: ['RS256']
  });
  next();
}

const isAuth = (req, res, next) => {
  console.log("req.user, req.auth",req.user, req.auth);
  // let user = req.profile && req.auth && req.profile._id == req.auth._id;
  // if (!user) {
  //   return res.status(403).json({ error: 'Access denied' });
  // }
  next();
}

const auth = passport.authenticate('jwt', { session: false });

const grantAccess = function (action, resource) {
  return async (req, res, next) => {
    try {
      console.log("console=======================", req.data.role);
      const permission = roles.can(req.user.role)[action](resource);
      if (!permission.granted) {
        return res.status(401).json({
          error: "You don't have enough permission to perform this action",
        });
      }
      next();
    } catch (error) {
      next(error);
    }
  };
};

const allowIfLoggedin = async (req, res, next) => {
  try {
    const user = res.locals.loggedInUser;
    console.log("res.locals.loggedInUser", user);
    if (!user)
      return res.status(401).json({
        error: "Please Login First",
      });
    next();
  } catch (error) {
    next(error);
  }
};

module.exports = {
    authClientToken : authClientToken,
    requireSignin: requireSignin,
    grantAccess: grantAccess,
    allowIfLoggedin: allowIfLoggedin,
    isAuth: isAuth,
    auth: auth,
    authenticateRoute
}