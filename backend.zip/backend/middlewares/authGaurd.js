const express = require('express');
const jwt = require('jsonwebtoken');
const config = require('../config/env_config/config');
const { roles } = require('../middlewares/roles');
const userModel = require('../models/user');

const authClientToken = async (req,res,next) => {

    let token = req.headers['x-access-token'];
    
    if (!token){
        return res.status(401).json({
            "errors" : [{
                "msg" : " No token provided"
            }]
        });
    } 
    await jwt.verify(token,config.secret, (err,decoded) => {
        if(err){
            return res.status(401).json({
                "errors" : [{
                    "msg" : "Invalid Token"
                }]
            });
        }
        return next();
    });
}

const grantAccess = function (action, resource) {
  return async (req, res, next) => {
    try {
      console.log("console=======================", req.data.role);
      const permission = roles.can(req.user.role)[action](resource);
      if (!permission.granted) {
        return res.status(401).json({
          error: "You don't have enough permission to perform this action",
        });
      }
      next();
    } catch (error) {
      next(error);
    }
  };
};

const allowIfLoggedin = async (req, res, next) => {
  try {
    const user = res.locals.loggedInUser;
    console.log("res.locals.loggedInUser", user);
    if (!user)
      return res.status(401).json({
        error: "Please Login First",
      });
    req.user = user;
    next();
  } catch (error) {
    next(error);
  }
};

module.exports = {
    authClientToken : authClientToken,
    grantAccess: grantAccess,
    allowIfLoggedin: allowIfLoggedin
}