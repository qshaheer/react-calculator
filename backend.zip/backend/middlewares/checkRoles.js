const _ = require('lodash');
const ROLES = {
    Admin: 'admin',
    User: 'basic',
    Supervisor: 'supervisor'
};
const checkRole = (...roles) => (req, res, next) => {
      console.log('\n\n', "==== |new req role |====", req.user);
      const authenticationWhiteList = [
        'GET /api/v2/products', 'GET /api/v2/products/'
      ];
    
      let route = `${req.method} ${req.originalUrl}`
      console.log("====inside authenticateRute===*", route, "*====");
      // console.log("=====**req.user**=======", request.user);
      if (_.indexOf(authenticationWhiteList, route) !== -1) {
        next();
      } else {
        if (!req.user) {
            return res.status(401).json({ error: 'Unauthorized' });
        }
        const hasRole = roles.find(role => req.user.role === role);
        if (!hasRole) {
            return res.status(403).json({ error: 'You are not allowed to make this request.' });
        }
        console.log('\n\n', "==== checkRole executed====");
        return next();
      }
};

const role = { ROLES, checkRole };

module.exports = role;