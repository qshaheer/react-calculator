const { body } = require('express-validator/check')

const validateAddCategoryBody = () => {
    return [ 
        body('name')
        .exists()
        .withMessage('name field is required')
        .isLength({min:3})
        .withMessage('name must be greater than 3 letters')
       ] 
} 

module.exports = {
    validateAddCategoryBody : validateAddCategoryBody
}