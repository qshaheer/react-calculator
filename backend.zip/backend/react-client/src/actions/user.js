import { REGISTER_USER_REQUEST, REGISTER_USER_SUCCESS, REGISTER_USER_FAILED } from '../constants/usersActionTypes';
import { SNACKBAR_SUCCESS, SNACKBAR_CLEAR } from '../constants/commonActionTypes';
import axios from 'axios';
// import { notification } from 'antd';
export const registerUser = (user) => (dispatch, getState) => {
    console.log("====user======", user);
  dispatch({
   type: REGISTER_USER_REQUEST
  });
  return fetch(
      'http://localhost:4000/api/signup',
      {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(user)
      }).then(({ data }) => {
    dispatch({ type: REGISTER_USER_SUCCESS, payload: data });
  }).catch(() => {
    dispatch({ type: REGISTER_USER_FAILED});
  });
 }
 export const showSuccessSnackbar = message => (dispatch, getState) => {
  dispatch({ type: SNACKBAR_SUCCESS });
 }
 export const clearSnackBar = message => (dispatch, getState) =>  {
  dispatch({ type: SNACKBAR_CLEAR });
 }