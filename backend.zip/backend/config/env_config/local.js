//local.js file (server/config/env_config)
let localConfig = {
    hostname: 'localhost',
    port: 4000,
    secret : 'restapisecret',
  };
  
  module.exports = localConfig;