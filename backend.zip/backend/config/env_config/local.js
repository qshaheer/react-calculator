//local.js file (server/config/env_config)
let localConfig = {
    hostname: 'localhost',
    port: 3000,
    secret : 'restapisecret',
  };
  
  module.exports = localConfig;