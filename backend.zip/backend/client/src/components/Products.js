import React, { Component } from 'react';
import { getAllProducts } from '../actions/products';
import { connect } from 'react-redux';


class Products extends Component {
    simpleAction = (event) => {
    this.props.getProducts();
    }
    render() {
        return (
          <div>
            <header className="App-header">
              <p>
                <button onClick={this.simpleAction}>Test redux action</button>
              </p>
              <pre>{JSON.stringify(this.props.products)}</pre>
            </header>
          </div>
        );
    }
}

const mapStateToProps = state => ({
    ...state
})
const mapDispatchToProps = dispatch => ({
getProducts: () => dispatch(getAllProducts())
})
export default connect(mapStateToProps, mapDispatchToProps)(Products);