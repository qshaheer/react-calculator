import React, { Component } from 'react'
import { Field, reduxForm } from 'redux-form'
import TextField from '@material-ui/core/TextField'
import { connect } from 'react-redux';
import Checkbox from '@material-ui/core/Checkbox'
import FormControlLabel from '@material-ui/core/FormControlLabel'
import FormControl from '@material-ui/core/FormControl'
import Select from '@material-ui/core/Select'
import InputLabel from '@material-ui/core/InputLabel'
import FormHelperText from '@material-ui/core/FormHelperText'
import Radio from '@material-ui/core/Radio'
import RadioGroup from '@material-ui/core/RadioGroup'
import asyncValidate from '../../helpers/asyncValidate'
import validate from '../../helpers/validate';
import Button from '@material-ui/core/Button';
import CloudUploadIcon from '@material-ui/icons/CloudUpload';
import { registerUser } from '../../actions/user';

const renderTextField = ({
  label,
  input,
  meta: { touched, invalid, error },
  ...custom
}) => (
  <TextField
    label={label}
    placeholder={label}
    error={touched && invalid}
    helperText={touched && error}
    {...input}
    {...custom}
  />
)

const renderButtonField = ({ type='contained', color='primary', method }) => (
    <Button variant={type} onClick={method} color={color}>Submit</Button>
)


const renderCheckbox = ({ input, label }) => (
  <div>
    <FormControlLabel
      control={
        <Checkbox
          checked={input.value ? true : false}
          onChange={input.onChange}
        />
      }
      label={label}
    />
  </div>
)

const radioButton = ({ input, ...rest }) => (
  <FormControl>
    <RadioGroup {...input} {...rest}>
      <FormControlLabel value="female" control={<Radio />} label="Female" />
      <FormControlLabel value="male" control={<Radio />} label="Male" />
      <FormControlLabel value="other" control={<Radio />} label="Other" />
    </RadioGroup>
  </FormControl>
)

const renderFromHelper = ({ touched, error }) => {
  if (!(touched && error)) {
    return
  } else {
    return <FormHelperText>{touched && error}</FormHelperText>
  }
}



const renderSelectField = ({
  input,
  label,
  meta: { touched, error },
  children,
  ...custom
}) => (
  <FormControl error={touched && error}>
    <InputLabel htmlFor="age-native-simple">Age</InputLabel>
    <Select
      native
      {...input}
      {...custom}
      inputProps={{
        name: 'age',
        id: 'age-native-simple'
      }}
    >
      {children}
    </Select>
    {renderFromHelper({ touched, error })}
  </FormControl>
)


class Register extends Component {
  state = {
    streamFile: [],
    name: '',
    email: '',
    password: '',
    formData: new FormData()
  }


  handleChange = name => event => {
    console.log("========name=======", name);
    const { formData } = this.state;
    const value = name === 'streamFile' ? event.target.files[0] : event.target.value;
    this.setState({ [name]: value });
  };

  handleAddProduct = (e) => {
    e.preventDefault();
    const { registerUser } = this.props;
    const { name, email, password, streamFile, formData } = this.state;
    formData.append('name', name);
    formData.append('email', email);
    formData.append('password', password);
    formData.append('streamFile', streamFile);
    registerUser(formData);
  }

  render() {
    return (
      <div>
        <form onSubmit={this.handleAddProduct}>
          <div>
            {/* <h2>REGISTRATION</h2> */}
            <div>
              <Field
                name="name"
                component={renderTextField}
                onChange={this.handleChange('name')}
                label="Full Name"
              />
            </div>
            <div>
              <Field
                name="email"
                component={renderTextField}
                onChange={this.handleChange('email')}
                label="Email"
              />
            </div>
            <div>
              <Field
                name="password"
                component={renderTextField}
                onChange={this.handleChange('password')}
                label="Password"
                type="password"
              />
            </div>
            <div style={{ marginTop: "5px", padding: "35px" }}>
              <label htmlFor="contained-button-file">
                <Button
                  variant="contained"
                  color="primary"
                  size="small"
                  component="span"
                >
                  Choose Picture
                  <input
                    accept="image/*"
                    // className={classes.input}
                    id="contained-button-file"
                    type="file"
                    style={{ display: "none" }}
                    onChange={this.handleChange('streamFile')}
                  />
                </Button>
              </label>
            </div>
            <div style={{ marginTop: "5px", padding: "35px" }}>
              <Button
                type="submit"
                size="small"
                variant="contained"
                color="primary"
                disabled={this.props.pristine || this.props.submitting}
              >
                SUBMIT
              </Button>
            </div>
          </div>
        </form>
      </div>
    );
  }
}

const mapStateToProps = ({  }) => ({ });
const mapDispatchToProps = dispatch => ({
  registerUser: (userData) => { dispatch(registerUser(userData)) }
});

Register = connect(
  mapStateToProps,
  mapDispatchToProps
)(Register);

export default reduxForm({
  form: 'register', // a unique identifier for this form
  validate,
  asyncValidate
})(Register)