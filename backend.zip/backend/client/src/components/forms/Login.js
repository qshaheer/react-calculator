import React, {Component} from 'react'
import { Field, reduxForm } from 'redux-form'
import { connect } from 'react-redux'
import TextField from '@material-ui/core/TextField'
import Checkbox from '@material-ui/core/Checkbox'
import FormControlLabel from '@material-ui/core/FormControlLabel'
import FormControl from '@material-ui/core/FormControl'
import Select from '@material-ui/core/Select'
import InputLabel from '@material-ui/core/InputLabel'
import FormHelperText from '@material-ui/core/FormHelperText'
import Radio from '@material-ui/core/Radio'
import RadioGroup from '@material-ui/core/RadioGroup'
import asyncValidate from '../../helpers/asyncValidate'
import validate from '../../helpers/validate';
import Button from '@material-ui/core/Button';
import { loginUser } from '../../actions/user';
import { withRouter } from 'react-router';

const renderTextField = ({
  label,
  input,
  meta: { touched, invalid, error },
  ...custom
}) => (
  <TextField
    label={label}
    placeholder={label}
    error={touched && invalid}
    helperText={touched && error}
    {...input}
    {...custom}
  />
)

const renderButtonField = ({ type='contained', color='primary', method }) => (
    <Button variant={type} onClick={method} color={color}>Submit</Button>
)

const renderCheckbox = ({ input, label }) => (
  <div>
    <FormControlLabel
      control={
        <Checkbox
          checked={input.value ? true : false}
          onChange={input.onChange}
        />
      }
      label={label}
    />
  </div>
)

const radioButton = ({ input, ...rest }) => (
  <FormControl>
    <RadioGroup {...input} {...rest}>
      <FormControlLabel value="female" control={<Radio />} label="Female" />
      <FormControlLabel value="male" control={<Radio />} label="Male" />
      <FormControlLabel value="other" control={<Radio />} label="Other" />
    </RadioGroup>
  </FormControl>
)

const renderFromHelper = ({ touched, error }) => {
  if (!(touched && error)) {
    return
  } else {
    return <FormHelperText>{touched && error}</FormHelperText>
  }
}


const renderSelectField = ({
  input,
  label,
  meta: { touched, error },
  children,
  ...custom
}) => (
  <FormControl error={touched && error}>
    <InputLabel htmlFor="age-native-simple">Age</InputLabel>
    <Select
      native
      {...input}
      {...custom}
      inputProps={{
        name: 'age',
        id: 'age-native-simple'
      }}
    >
      {children}
    </Select>
    {renderFromHelper({ touched, error })}
  </FormControl>
)

class LoginForm extends Component {
  state = {
    email: '',
    password: ''
  }
  handleChange = (name) => event => {
    this.setState({ [name]: event.target.value });
  }
  handleLogin = (e) => {
    e.preventDefault();
    const { email, password } = this.state;
    const { loginUser } = this.props;
    loginUser({ email, password });
    this.props.history.push({
      pathname: '/dashboard'
    });
  }
  render() {
    const { pristine, reset, submitting, classes } = this.props;
    return (
      <form onSubmit={this.handleLogin}>
        <div>
          {/* <h2>LOG IN</h2> */}
        <div>
          <Field name="email" component={renderTextField} label="Email" onChange={this.handleChange('email')} />
        </div>
        <div>
          <Field
            name="password"
            component={renderTextField}
            label="Password"
            type="password"
            onChange={this.handleChange('password')}
          />
        </div>

 

        <div style={{ marginTop:'5px', padding:'35px' }}>
          <Button type='submit' size="small" variant='contained' color='primary' disabled={pristine || submitting}>
            SUBMIT
          </Button>
        </div>
        </div>
      </form>
    );
  }
}
const mapStateToProps = ({  }) => ({ });
const mapDispatchToProps = dispatch => ({
  loginUser: ({ email, password }) => { dispatch(loginUser({ email, password })) }
});

LoginForm = connect(
  mapStateToProps,
  mapDispatchToProps)(LoginForm);
export default reduxForm({
  form: 'login', // a unique identifier for this form
  validate,
  asyncValidate
})(withRouter(LoginForm))