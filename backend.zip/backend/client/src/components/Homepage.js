import React, { Component } from 'react';
import { Button } from  '@material-ui/core';
import CssBaseline from '@material-ui/core/CssBaseline';
import Typography from '@material-ui/core/Typography';
import Container from '@material-ui/core/Container';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import Register from './forms/Register';
import Login from './forms/Login';
import { connect } from 'react-redux';
import Grid from '@material-ui/core/Grid';
import { logoutUser } from '../actions/user';
// import '../../images/profile-pic.png';
// import showResults from '../helpers/showResults';
const styles = theme => ({
    root: {
      marginTop: theme.spacing.unit *3,
      width: '100%'
    },
    flex: {
      flex: 1
    },
    menuButton: {
      marginLeft: -12,
      marginRight: 20
    },
    nav: {
      paddingLeft: 90
    },
    container: {

    }
  })
class Homepage extends Component {
  showResults = (values) => {
    console.log("====values======", values);
    const { registerUser } = this.props;
    // registerUser(values);
  }
    handleLogout = () => {
      console.log("====logoutUser======", this.props);
      const { logoutUser } =this.props;
      logoutUser();
    }
    render() {
      const { user } = this.props;
        return (
            <div className={styles.root}>
                <header className="lg:px-16 px-6 bg-white flex flex-wrap items-center lg:py-0 py-2">
                  <div className="flex-1 flex justify-between items-center">
                    <a href="#">
                      Router
                    </a>
                  </div>

                  <label htmlFor="menu-toggle" className="pointer-cursor lg:hidden block"><svg className="fill-current text-gray-900" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>menu</title><path d="M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z"></path></svg></label>
                  <input className="hidden" type="checkbox" id="menu-toggle" />

                  <div className="hidden lg:flex lg:items-center lg:w-auto w-full" id="menu">
                    <nav>
                      <ul className="lg:flex items-center justify-between text-base text-gray-700 pt-4 lg:pt-0">
                        {/* <li><a className="lg:p-4 py-3 px-0 block border-b-2 border-transparent hover:border-indigo-400" href="#">Features</a></li>
                        <li><a className="lg:p-4 py-3 px-0 block border-b-2 border-transparent hover:border-indigo-400" href="#">Pricing</a></li>
                        <li><a className="lg:p-4 py-3 px-0 block border-b-2 border-transparent hover:border-indigo-400" href="#">Documentation</a></li>
                        <li><a className="lg:p-4 py-3 px-0 block border-b-2 border-transparent hover:border-indigo-400 lg:mb-0 mb-2" href="#">Support</a></li> */}
                      </ul>
                    </nav>

                    {(localStorage.getItem('loginToken')) &&
                      <div>
                        <a href="#" className="lg:ml-4 flex items-center justify-start lg:mb-0 mb-4 pointer-cursor">
                         <img className="rounded-full w-10 h-10 border-2 border-transparent hover:border-indigo-400" src="/images/profile-pic.png" alt="user"/>
                        </a>
                        <Button variant="outlined" className="lg:ml-4 flex items-center justify-start lg:mb-0 mb-4 pointer-cursor" size="small" color="primary" href="#outlined-buttons" onClick={this.handleLogout}>
                          LOG OUT
                        </Button>
                      </div>
                    }
                  </div>
                </header>
                <Container className={styles.container}>
                <Grid container spacing={1} style={{ textAlign: 'center', marginTop: 30}}>
                  <Grid item xs={6}>
                    <Register onSubmit={this.showResults}/>
                  </Grid>
                  <Grid container item xs={6}>
                    <Login />
                  </Grid>
                </Grid>
                </Container>
            </div>
        );
    }
}

const mapStateToProps = ({  }) => ({  });

const mapDispatchToProps = (dispatch) => ({
  logoutUser: () => { dispatch(logoutUser()) }
});

export default connect(mapStateToProps, mapDispatchToProps)(Homepage);