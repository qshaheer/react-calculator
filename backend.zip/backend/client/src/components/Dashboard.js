import React, { Component } from 'react';


class Dashboard extends Component {
    render() {
        return (
            <div>
                Dashboard
            </div>
        );
    }
}

export default Dashboard;