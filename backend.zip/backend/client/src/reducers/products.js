const productState = {
  loading: false,
  successSnackbarOpen: false,
  result: []
};

export default (state = productState, action) => {
    switch (action.type) {
     case 'GET_ALL_PRODUCTS':
      return {
       ...state,
       result: action.payload
      }
     default:
      return state;
    }
}