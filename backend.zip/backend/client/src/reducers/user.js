const userState = {
    fetching: false,
  };
  
  const user = (state = {}, action) => {
    switch (action.type) {
      case "REGISTER_USER_REQUEST":
        return {
          ...state,

        };
      case "USER":
        return {
          ...state,
        };
      default:
        return state;
    }
  };
  
  export default user;