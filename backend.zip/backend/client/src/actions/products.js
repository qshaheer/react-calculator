import {GET_ALL_PRODUCTS } from '../constants/actionTypes';
export const getAllProducts = () => dispatch => {
  dispatch({
   type: GET_ALL_PRODUCTS,
   payload: 'payload of getAllproducts'
  })
 }