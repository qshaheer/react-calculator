import { REGISTER_USER_REQUEST, REGISTER_USER_SUCCESS,  REGISTER_USER_FAILED, FIND_USER_REQUEST, FIND_USER_SUCCESS, FIND_USER_FAILED } from '../constants/usersActionTypes';
import { SNACKBAR_SUCCESS, SNACKBAR_CLEAR } from '../constants/commonActionTypes';
import axios from 'axios';
// import { notification } from 'antd';
const url = 'http://localhost:7000';
export const registerUser = (user) => (dispatch, getState) => {
  console.log("====***UseR***=====", user);
  dispatch({
   type: REGISTER_USER_REQUEST
  });
  // return fetch(
  //     `${url}//api/v1/auth/register`,
  //     {
  //       method: 'POST',
  //       headers: {
  //         Accept: 'application/json, application/xml, text/plain, text/html',
  //         'Content-Type': 'multipart/form-data'
  //       },
  //       body: user
  //     })
  return axios.post(`${url}/api/v1/auth/register`, user, {
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  }).then(({ data }) => {
    dispatch({ type: REGISTER_USER_SUCCESS, payload: data });
  }).catch(() => {
    dispatch({ type: REGISTER_USER_FAILED});
  });
 }
 export const getUser = () => (dispatch, getState) => {
    let userId = '';
    dispatch({ type: FIND_USER_REQUEST });
    if ((localStorage.getItem('userInfo'))) {
      userId = localStorage.getItem('userInfo');
    }

    return axios({
      method: 'get',
      url: `${url}/api/v1/users/findUser`,
      params: { userId } 
      })
      .catch(() => {
      dispatch({ type: FIND_USER_FAILED });
    })
 }
 export const loginUser = ({ email, password}) => (dispatch, getState) => {

   return axios.post(`${url}/api/v1/auth/login`, {
     email, password
   }).then((payload) => {
     const { data } = payload;
     if (data) {
       const { _id, token } = data; 
      localStorage.setItem('loginToken', token);
      console.log("====_id=====, ===token====", _id, token);
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      axios.defaults.headers.common.userInfo = data.data._id;
     }
   });
 }
 export const showSuccessSnackbar = message => (dispatch, getState) => {
  dispatch({ type: SNACKBAR_SUCCESS });
 }
 export const clearSnackBar = message => (dispatch, getState) =>  {
  dispatch({ type: SNACKBAR_CLEAR });
 }