import { LOGIN_USER_REQUEST, LOGIN_USER_SUCCESS,  LOGIN_USER_FAILED, REGISTER_USER_REQUEST, REGISTER_USER_SUCCESS,  REGISTER_USER_FAILED, FIND_USER_REQUEST, FIND_USER_SUCCESS, FIND_USER_FAILED } from '../constants/usersActionTypes';
import { SNACKBAR_SUCCESS, SNACKBAR_CLEAR } from '../constants/commonActionTypes';
import axios from 'axios';
// import { notification } from 'antd';
const url = 'http://localhost:7000';
export const registerUser = (user) => (dispatch, getState) => {
  console.log("====***UseR***=====", user);
  dispatch({
   type: REGISTER_USER_REQUEST
  });
  // return fetch(
  //     `${url}//api/v1/auth/register`,
  //     {
  //       method: 'POST',
  //       headers: {
  //         Accept: 'application/json, application/xml, text/plain, text/html',
  //         'Content-Type': 'multipart/form-data'
  //       },
  //       body: user
  //     })
  return axios.post(`${url}/api/v1/auth/register`, user, {
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  }).then(({ data }) => {
    console.log("===registerUserData===", data);
    dispatch({ type: REGISTER_USER_SUCCESS, payload: data });
  }).catch(() => {
    dispatch({ type: REGISTER_USER_FAILED});
  });
 }
 export const getUser = () => (dispatch, getState) => {
    let userId = ''; let token = '';
    dispatch({ type: FIND_USER_REQUEST });
    if ((localStorage.getItem('userInfo'))) {
      userId = localStorage.getItem('userInfo');
    }
    if ((localStorage.getItem('loginToken'))) {
      token = localStorage.getItem('loginToken');
    }

    return axios({
      method: 'get',
      url: `${url}/api/v1/users/findUser`,
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`
      },
      params: { userId } 
      }).then((data) => {
        console.log("===findUserData===", data);
        dispatch({ type: FIND_USER_SUCCESS , payload: data })
      })
      .catch(() => {
        if(localStorage.getItem('loginToken')){
          localStorage.removeItem('loginToken');
        }
        dispatch({ type: FIND_USER_FAILED });
    })
 }
 export const loginUser = ({ email, password}) => (dispatch, getState) => {
  dispatch({ type: LOGIN_USER_REQUEST })
   return axios.post(`${url}/api/v1/auth/login`, {
     email, password
   }).then((payload) => {
     const { data } = payload;
     if (data) {
       const { _id, token } = data; 
      localStorage.setItem('loginToken', token);
      console.log("===loginUserData===", data);
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      axios.defaults.headers.common.userInfo = data.data._id;
      dispatch({ type: LOGIN_USER_SUCCESS , payload: data });
     }
   }).catch(() => {
     dispatch({ type: LOGIN_USER_FAILED })
   });
 }

 export const logoutUser = () => (dispatch, getState) => {
  if (typeof window !== 'undefined') {
    if(localStorage.getItem('loginToken')){
      localStorage.removeItem('loginToken');
    }
  }
 }
 export const showSuccessSnackbar = message => (dispatch, getState) => {
  dispatch({ type: SNACKBAR_SUCCESS });
 }
 export const clearSnackBar = message => (dispatch, getState) =>  {
  dispatch({ type: SNACKBAR_CLEAR });
 }