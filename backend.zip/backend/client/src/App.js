import React, {Component} from 'react';
import {connect} from 'react-redux';
import Products from './components/Products';
import Homepage from './components/Homepage';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import './App.css';
import './tailwind.output.css';
import { getUser } from './actions/user';
import Dashboard from './components/Dashboard';

class App extends Component {
  state = {
    authToken: localStorage.getItem('loginToken'),
  };
  componentDidMount(){
    const { getUser } = this.props;
    const { authToken } = this.state;

    if (authToken) {
      getUser();
    }
  }
  render() {
    const { user } = this.props;
    // console.log("====***ROUTE USER****=====", user);
    // console.log("===loginToken===", this.state.authToken);
    return (
      <>
        <Router>
          <Switch>
            <Route exact path="/" component={Homepage} user={user} />
            <Route exact path="/products" component={Products} user={user} />
            <Route exact path="/dashboard" component={Dashboard} user={user} />
          </Switch>
        </Router>
        </>
    );
  }
}
const mapStateToProps = ({  }) => ({  });

const mapDispatchToProps = dispatch => ({
  getUser: () => dispatch(getUser())
});
export default connect(mapStateToProps, mapDispatchToProps)(App);
