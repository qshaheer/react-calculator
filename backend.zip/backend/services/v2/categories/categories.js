const express = require('express');
const categoryModel = require('../../../models/category');
const { validationResult } = require('express-validator/check');

const getCategoryDetails = async (req,res,next) => {

    let { categoryId } = req.params;

    let categories = await categoryModel.findById(categoryId);

    if(!categories){
        return res.status(404).json({
            "errors":[{
                "msg" : " no categories found"
            }]
        })
    }

    return res.status(200).json({
        "success" : true,
        "msg" : " categories fetched successfully",
        data : categories
    })
}

const getAllCategories = async (req,res,next) => {
    let categories = await categoryModel.find({});
    if(!categories){
        return res.status(404).json({
            "errors":[{
                "msg": "no categories exists"
            }]
        })
    }
    return res.status(200).json({
        "success" : true,
        "msg" : " categories fetched successfully",
        data : categories,
        total_records : categories.length
    });
}


const addCategory = async (req,res,next) => {
    const errors = validationResult(req);
    if(!errors.isEmpty()){
        return res.status(422).json({ errors: errors.array() });
    }

    let { name } = req.body;


    try {

      let isCategoryExists = await categoryModel.findOne({ name });

      if (isCategoryExists) {
        return res.status(409).json({
          errors: [
            {
              msg: "category already exists",
            },
          ],
        });
      }
      let category = await categoryModel.create({
        name: name
      });
      if (!category) {
        throw new error();
      }

      return res.status(201).json({
        success: [
          {
            msg: "category registered successfully",
          },
        ],
      });
    } catch (error) {
      console.log(error);
      return res.status(500).json({
        errors: [
          {
            msg: "there was a problem adding a category.",
          },
        ],
      });
    }
    

}

module.exports = {
    getCategoryDetails : getCategoryDetails,
    getAllCategories : getAllCategories,
    addCategory : addCategory
}