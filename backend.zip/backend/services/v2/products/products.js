const express = require('express');
var fs = require('fs');
const _ = require('lodash');
const formidable = require('formidable'); 
const productModel = require('../../../models/product');
const categoryModel = require('../../../models/category');
const { validationResult } = require('express-validator/check');
var csv = require('csvtojson'); 

const getProductDetails = async (req,res,next) => {

    let { productId } = req.params;

    let products = await productModel.findById(productId).select({ '_id':0, 'name':1 , 'price':1 , 'description':1});

    if(!products){
        return res.status(404).json({
            "errors":[{
                "msg" : " no product found"
            }]
        })
    }
    var productArray = [];
    let productObj = {};
    let categoryId = await productModel.findById(productId);
    let category = await categoryModel.findById(categoryId.category);
    const { _doc } = products;
    if (category) {
      productObj = {
        ..._doc,
        "category": category.name
      }
      productArray.push(productObj);
    }
    return res.status(200).json({
        "success" : true,
        "msg" : " product fetched successfully",
        data : productArray
    })
}


const getAllProducts = async (req,res,next) => {
  console.log("/n/n=====inside=====products");
    let products = await productModel.find({}).select({'_id':0, 'name':1 , 'price':1 , 'description':1 });
    if(!products){
        return res.status(404).json({
            "errors":[{
                "msg": "no product exists"
            }]
        })
    }
    return res.status(200).json({
        "success" : true,
        "msg" : " products fetched successfully",
        data : products,
        total_records : products.length
    });
}

const addProductFromFile = async (req,res,next) => {
  try {
    // let iscategoryExists = await categoryModel.findById({ _id: category });
    // if (iscategoryExists) {
      // if (isProductExists) {
      //   return res.status(409).json({
      //     errors: [
      //       {
      //         msg: "product already exists",
      //       },
      //     ],
      //   });
      // }
      var temp;
      csv()
        .fromFile(req.file.path)
        .then((jsonObj) => {
          for (var x = 0; x < jsonObj; x++) {
            temp = parseFloat(jsonObj[x].Price);
            jsonObj[x].Price = temp;
          }
          productModel.insertMany(jsonObj, (err, data) => {
            if (err) {
              console.log(err);
            } else {
              return res.status(201).json({
                success: [
                  {
                    msg: "products added successfully",
                  },
                ],
              });
            }
          });
        });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      errors: [
        {
          msg: "there was a problem adding the products.",
        },
      ],
    });
  }
}

// const removeProduct = async (req,res,next) => {
//   try {

//   }
//   catch (ex) {}
// }

const addProduct = async (req,res,next) => {

    // const errors = validationResult(req);
    // if(!errors.isEmpty()){
    //     return res.status(422).json({ errors: errors.array() });
    // }
    try {
      console.log("===req.body===", req.body);
      console.log("===req.body.file===", req.files);
      const { name, price, description, category } = req.body;
      let fields ={};
      if (!_.isEmpty(req.files)) {
        var productImage = new productModel();
        if (req.files.length === 3) {
          productImage.img1.data = fs.readFileSync(req.files[0].path);
          productImage.img1.contentType = 'image/png';
          productImage.img2.data = fs.readFileSync(req.files[1].path);
          productImage.img2.contentType = 'image/png'; 
          productImage.img3.data = fs.readFileSync(req.files[3].path);
          productImage.img3.contentType = 'image/png';
          await productModel.create({
            name,
            price,
            description,
            category,
            img1: productImage.img1,
            img2: productImage.img2,
            img3: productImage.img3
          });
          return res.status(201).json({
            success: [
              {
                msg: "product added successfully",
              },
            ],
          });
        }
        if (req.files.length === 2) {
          productImage.img1.data = fs.readFileSync(req.files[0].path);
          productImage.img1.contentType = 'image/png';
          productImage.img2.data = fs.readFileSync(req.files[1].path);
          productImage.img2.contentType = 'image/png'; 
          await productModel.create({
            name,
            price,
            description,
            category,
            img1: productImage.img1,
            img2: productImage.img2
          });
          return res.status(201).json({
            success: [
              {
                msg: "product added successfully",
              },
            ],
          });
        }
        if (req.files.length === 1) {
          console.log("==Only One Image==");
          productImage.img1.data = fs.readFileSync(req.files[0].path);
          productImage.img1.contentType = 'image/png';
          await productModel.create({
            name,
            price,
            description,
            category,
            img1: productImage.img1
          });
          return res.status(201).json({
            success: [
              {
                msg: "product added successfully",
              },
            ],
          });
        }
      } else {
        console.log("===no image==");
        fields = {
          name,
          price,
          description,
          category
        }
        await productModel.create({
          ...fields
        });
        return res.status(201).json({
          success: [
            {
              msg: "product added successfully",
            },
          ],
        });
      }

      //Parses an incoming node.js request containing form data


        // console.log("===========================");
        // console.log("=====fields=====",fields);
        // if (err) {
        //   return res.status(400).json({
        //     error: 'Image could not be uploaded'
        //   });
        // }
    
        // let product = new productModel(fields);
    
        // // 1kb = 1000
        // // 1mb = 1000000
        // // console.log("=====fields=====",fields);
        // if (files.photo) {
        //   // console.log('FILES PHOTO: ', files.photo);
        //   if (files.photo.size > 1000000) {
        //     return res.status(400).json({
        //       error: 'Image should be less than 1 MB in size'
        //     });
        //   }
        //   //read the photo file and save into database
        //   product.photo.data = fs.readFileSync(req.files.path);
        //   product.photo.contentType = req.files.photo.type;
        // }
    
        // product.save((err, result) => {
        //   if (err) {
        //     return res.status(400).json({
        //       error: err.message
        //     });
        //   }
        //   res.json(result);
        // });

    }
    catch (error) {
        console.log(error);
        return res.status(500).json({
          errors: [
            {
              msg: "there was a problem adding a product.",
            },
          ],
        });
      }



    // const errors = validationResult(req);
    // if(!errors.isEmpty()){
    //     return res.status(422).json({ errors: errors.array() });
    // }

    // let { name, category, price, description } = req.body;

    // try {

    //   let isProductExists = await productModel.findOne({ name });
      
    //   let iscategoryExists = await categoryModel.findById({ _id: category });
    //   if(iscategoryExists){
    //     if (isProductExists) {
    //       return res.status(409).json({
    //         errors: [
    //           {
    //             msg: "product already exists",
    //           },
    //         ],
    //       });
    //     }
    //     var productImage = new productModel();
    //     if (req.files.length){
    //       console.log("files.img.path================", req.files[0].path);
    //       productImage.img.data = fs.readFileSync(req.files[0].path)
    //       productImage.img.contentType = 'image/png';
    //     }
    //     let product = await productModel.create({
    //       name: name,
    //       category: category,
    //       price: price,
    //       description: description || "no description provided",
    //       img: productImage.img || null
    //     });
    //     if (!product) {
    //       throw new error();
    //     }
  
    //     return res.status(201).json({
    //       success: [
    //         {
    //           msg: "product registered successfully",
    //         },
    //       ],
    //     });
    //   }
    //   else{
    //     return res.status(409).json({
    //       errors: [
    //         {
    //           msg: "category don't exists",
    //         },
    //       ],
    //     });
    //   }
    // } catch (error) {
    //   console.log(error);
    //   return res.status(500).json({
    //     errors: [
    //       {
    //         msg: "there was a problem adding a product.",
    //       },
    //     ],
    //   });
    // }
    

}

module.exports = {
    getProductDetails : getProductDetails,
    getAllProducts : getAllProducts,
    addProduct : addProduct,
    addProductFromFile : addProductFromFile,
    // removeProduct : removeProduct
}