const express = require('express');
const productModel = require('../../../models/product');
const { validationResult } = require('express-validator/check');

const getProductDetails = async (req,res,next) => {

    let { productId } = req.params;

    let products = await productModel.findById(productId);

    if(!products){
        return res.status(404).json({
            "errors":[{
                "msg" : " no product found"
            }]
        })
    }

    return res.status(200).json({
        "success" : true,
        "msg" : " product fetched successfully",
        data : products
    })
}

const getAllProducts = async (req,res,next) => {
    let products = await productModel.find({});
    if(!products){
        return res.status(404).json({
            "errors":[{
                "msg": "no product exists"
            }]
        })
    }
    return res.status(200).json({
        "success" : true,
        "msg" : " products fetched successfully",
        data : products,
        total_records : products.length
    });
}


const addProduct = async (req,res,next) => {
    const errors = validationResult(req);
    if(!errors.isEmpty()){
        return res.status(422).json({ errors: errors.array() });
    }

    let { name } = req.body;


    try {

      let isProductExists = await productModel.findOne({ name });

      if (isProductExists) {
        return res.status(409).json({
          errors: [
            {
              msg: "product already exists",
            },
          ],
        });
      }
      let product = await productModel.create({
        name: name,
        category: category,
        price: price,
        description: description || "no description provided",
        imagePath: imagePath || null
      });
      if (!product) {
        throw new error();
      }

      return res.status(201).json({
        success: [
          {
            msg: "product registered successfully",
          },
        ],
      });
    } catch (error) {
      console.log(error);
      return res.status(500).json({
        errors: [
          {
            msg: "there was a problem adding a product.",
          },
        ],
      });
    }
    

}

module.exports = {
    getProductDetails : getProductDetails,
    getAllProducts : getAllProducts,
    addProduct : addProduct
}