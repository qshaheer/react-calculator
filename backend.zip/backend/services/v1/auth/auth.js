const express = require('express');
const bcrypt = require('bcryptjs');
const formidable = require('formidable');
const jwt = require('jsonwebtoken');
const { validationResult } = require('express-validator/check');
const fs = require('fs');

const config = require('../../../config/env_config/config');
const userModel = require('../../../models/user');

const register = async (req,res,next) => {
  const errors = await validationResult(req);
  if(!errors.isEmpty()) {
      return res.status(422).json({ errors: errors.array() });
  }
  // try {
  const form = await formidable({ multiples: true });
  console.log("=======req=======");
  // form.keepExtensions = true;
  //Parses an incoming node.js request containing form data
  console.log("req.body", req.body);
  console.log("req.body", req.streamFile);
  // form.on('file', function(field, file) {console.log("File incoming");});
  form.parse(req, async (err, fields, files) => {
    console.log("err", err, fields, files);


    // let { name, email , password, role } = fields;
    // let hashedPassword = await bcrypt.hash(password, 8);
    // console.log("=======executed=======", hashedPassword);

    // console.log("FILE:=====================================");

    // let isEmailExists = await userModel.findOne({ email: email });

    // if (isEmailExists) {
    //   return res.status(409).json({
    //     errors: [
    //       {
    //         msg: "email already exists",
    //       },
    //     ],
    //   });
    // }
    // var userImage = new userModel();
    // console.log("======files======", files, req.files);
    // if (files){
    //   console.log("======imgFiles======");
    //   // console.log("files.img.path===============", req.file.path);
    //   userImage.img.data = fs.readFileSync(files.path);
    //   userImage.img.contentType = 'image/png'; 
    // }
    // let user = await userModel.create({
    //   name: name,
    //   email: email,
    //   password: hashedPassword,
    //   role: role || "basic",
    //   img: userImage.img || null
    // });
    // // console.log("======imgFiles======");
    // if (!user) {
    //   // console.log("======imgFiles======");
    //   throw new error();
    // }
    // // console.log("======imgFiles======");
    // return res.status(201).json({
    //   success: [
    //     {
    //       msg: "user registered successfully",
    //     },
    //   ],
    // });
  });
  // const errors = validationResult(req);
  // if(!errors.isEmpty()) {
  //     return res.status(422).json({ errors: errors.array() });
  // }

  // let { name, email , password, role } = req.body;

  // let hashedPassword = await bcrypt.hash(password, 8);


  // } catch (error) {
  //   console.log(error);
  //   return res.status(500).json({
  //     errors: [
  //       {
  //         msg: "there was a problem registering a user.",
  //       },
  //     ],
  //   });
  // }
}

const login = async (req,res,next) => {

    const errors = validationResult(req);
    console.log("inside LoginBody", req.body);
    if(!errors.isEmpty()){
        return res.status(422).json({ errors: errors.array() });
    }

    try {
        let { email, password } = req.body
        let isUserExists = await userModel.findOne({ email });
        let isPasswordValid;
        if(isUserExists){
          isPasswordValid = await bcrypt.compare(password, isUserExists.password);
        }
       

        if(!isUserExists || !isPasswordValid){
            return res.status(401).json({
                "errors" : [{
                    "msg" : "email/password is wrong"
                }]
            })
        }
        else {
            let token = jwt.sign({ id: isUserExists._id }, 'secret1', { expiresIn: 86400 });
            res.status(200).json({
              msg: "user login successfully",
              data: {
                _id: isUserExists._id,
                email: isUserExists.email,
                name: isUserExists.name,
                role: isUserExists.role,
                img: isUserExists.img
              },
              token: token,
            });
        }
    }catch(error){
        console.log(error);
        return res.status(500).json(
            { 
                "errors" : [{
                    "msg": "there was a problem login a user."   
                }]
            }
        );
    } 
}

module.exports = {
    register : register,
    login : login
}