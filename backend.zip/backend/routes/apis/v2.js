const productController = require('../../controllers/apis/v2/products');
const categoryController = require('../../controllers/apis/v2/categories');
// const { authenticateRoute, auth, isAuth } = require('../../middlewares/authGaurd');
// const role = require('../../middlewares/checkRoles');
// const passport = require('passport');

const express = require('express');
let router = express.Router();
router.use('/products', productController);
router.use('/categories', categoryController);
module.exports = router;