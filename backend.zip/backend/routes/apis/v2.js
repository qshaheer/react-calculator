const productController = require('../../controllers/apis/v2/products');
const categoryController = require('../../controllers/apis/v2/categories');

const express = require('express');
let router = express.Router();
router.use('/products', productController);
router.use('/categories', categoryController);
module.exports = router;