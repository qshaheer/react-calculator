import * as express from 'express';
import Post from '../interfaces/post.interface'
import postModel from '../models/posts.model'
import PostNotFoundException from '../exceptions/PageNotFoundException'
import validationMiddleware from '../middlewares/validation.middleware';
import CreatePostDto from '../dtos/post.dto';
 
class PostsController {
  public path = '/posts';
  public router = express.Router();
 
  private posts: Post[] = [
    {
      author: 'Marcin',
      content: 'Dolor sit amet',
      title: 'Lorem Ipsum',
    }
  ];
 
  constructor() {
    this.intializeRoutes();
  }
 
  public intializeRoutes() {
    this.router.get(this.path, this.getAllPosts);
    this.router.get(`${this.path}/:id`, this.getPostById);
    this.router.patch(`${this.path}/:id`, validationMiddleware(CreatePostDto, true), this.modifyPost);
    this.router.delete(`${this.path}/:id`, this.deletePost);
    this.router.post(this.path, validationMiddleware(CreatePostDto), this.createPost);
  }
 
  getAllPosts = async (request: express.Request, response: express.Response) => {
    await postModel.find().then(posts => {
      response.send(posts);
    });
    response.send(this.posts);
  }

  modifyPost = async (request: express.Router, response: express.Router, next: express.NextFunction) => {
    const id = request.params.id;
    const postData: Post = request.body;
    await postModel.findByIdAndUpdate(id, postData, { new: true }).then(post => {
      if(post){
        response.send(post);
      }
      else{
        next(new PostNotFoundException(id));
      }
    });
  }

  getPostById = async ( request: express.Request ,response: express.Response, next: express.NextFunction ) => {
    const id = request.params.id;
    await postModel.findById(id).then(post => {
      if(post){
        response.send(post);
      }
      else {
        next(new PostNotFoundException(id));
      }
    });
  }

  createPost = (request: express.Request, response: express.Response) => {
    const postData: Post = request.body;
    const createdPost = new postModel(postData);
    createdPost.save()
      .then(savedPost => {
        response.send(savedPost);
      })
  }
  deletePost = async (request: express.Request, response: express.Response, next: express.NextFunction) => {
    const id = request.params.id;
    await postModel.findByIdAndDelete(id).then((successResponse) => {
      if (successResponse) {
        response.send(200);
      } else {
        next(new PostNotFoundException(id));
      }
    });
  }
}
 
export default PostsController;