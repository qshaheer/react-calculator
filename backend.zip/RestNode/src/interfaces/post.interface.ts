interface Post {
    author: string;
    content: string;
    title: string;
  }
   
export default Post;