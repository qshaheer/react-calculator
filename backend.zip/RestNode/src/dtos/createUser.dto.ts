import { IsString } from 'class-validator';
 
class createUserdto {
  @IsString()
  public email: string;
 
  @IsString()
  public password: string;
  
  @IsString()
  public firstName: string;

  @IsString()
  public lastName: string;
}
 
export default createUserdto;