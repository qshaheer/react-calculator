const models = require('../models');
var fs = require("fs");

const login = async (req, res) => {
    try {

    }
    catch (ex) {
        res.status(500).json({
            error: ex.message
        })
    }
};

const register = async (req, res) => {
    try {
        let readFileStream;
        let photoContentType;
        const user = await models.User.findOne({ 
            where: { email: req.body.email } 
        });

        if (req.files) {
            readFileStream = fs.readFileSync(req.files.photo.path);
            photoContentType = req.files.photo.type;
        }

        if (user) {
            return res.status(400).json({
                message: "Email already Exists"
            });
        }
        
        await models.User.create({
            name: req.body.name,
            email: req.body.email,
            password: req.body.password,
            role: req.body.role,
            photoContent: readFileStream ? readFileStream : null,
            contentType: photoContentType ? photoContentType : null,
        }).then((user)=> {
            res.status(201).json({
                user
            });
        });

    }
    catch (ex) {
        res.status(500).json({
            error: ex.message
        });
    }
}

const addUser = async (req, res) => {
    try {

    }
    catch (ex) {
        return res.status(500).json({
            error: ex.message
        })
    }
};

module.exports = {
    login,
    register,
    addUser
}