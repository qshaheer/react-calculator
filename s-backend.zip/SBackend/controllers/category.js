const models = require("../models");

const createCategory = async (req, res) => {
    try {
        const { name } = req.body;
        console.log("===name====", req.body);
        const Category = models.Category.create({
            name
        }).then((data) => {
            res.json(data);
        });
    }
    catch(ex) {
        res.status(500).json({
            error: ex.message
        })
    }
}

const getAllCategories = async (req, res) => {
    try {
        const { name } = req.body;
        console.log("===name====", req.body);
        const Category = models.Category.findAll({}).then((data) => {
            res.json(data);
        });
    }
    catch(ex) {
        res.status(500).json({
            error: ex.message
        })
    }
}

module.exports = {
    createCategory,
    getAllCategories
}