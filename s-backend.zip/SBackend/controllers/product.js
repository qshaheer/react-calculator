const models = require("../models");
var fs = require("fs");

const getAllProducts = async (req, res) => {
  try {
    const products = await models.Products.findAll({
      attributes: {
        exclude: [
          "contentType",
          "photoContent",
          "updatedAt",
          "createdAt",
          "CategoryId",
        ],
      },
      include: [
        {
          model: models.Category,
          as: "category",
        },
      ],
    });
    return res.status(201).json({
      data: products,
    });
  } catch (ex) {
    return res.status(500).json({
      error: ex.message,
    });
  }
};
const createProduct = async (req, res) => {
  try {
    const {
      name,
      price,
      quantity,
      sold,
      shipping,
      category,
      //   photoContent,
      //   contentType,
    } = req.body;

    let readFileStream;
    let photoContentType;
    console.log("====req.files.photo===", req.files, "===req=====", req.body);
    if (req.files) {
      console.log("====inside req.files.photo===");
      readFileStream = fs.readFileSync(req.files.photo.path);
      photoContentType = req.files.photo.type;
    }

    await models.Products.create({
      name,
      price,
      quantity,
      sold,
      shipping,
      photoContent: readFileStream ? readFileStream : null,
      contentType: photoContentType ? photoContentType : null,
      CategoryId: category,
    })
      .then((data) => {
        res.json(data);
      })
      .catch((err) => {
        console.error("Error on post: ", err);
        return res.status(400).send({ error: err.message });
      });
    // return res.status(201).json({
    //   data: products,
    // });
  } catch (ex) {
    return res.status(500).json({
      error: ex.message,
    });
  }
};

module.exports = {
  getAllProducts,
  createProduct,
};
