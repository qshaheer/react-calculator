'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn('Products', 'createdAt', {
        type: Sequelize.DATE, 
        defaultValue: Sequelize.NOW
      }),
      queryInterface.changeColumn('Products', 'updatedAt', {
        type: Sequelize.DATE, 
        defaultValue: Sequelize.NOW
      })
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn('Products', 'createdAt', {
        defaultValue: Sequelize.NOW
      }),
      queryInterface.changeColumn('Products', 'updatedAt', {
        defaultValue: Sequelize.NOW
      })
    ]);
  }
};
