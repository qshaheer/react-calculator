'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.renameColumn(
        'Products',
        'photo',
        'photoContent')
    ],
      queryInterface.addColumn(
        'Products',
        'contentType',
        { type: Sequelize.STRING }, {
        after: 'photoContent' // after option is only supported by MySQL
     }),
    );
  },

  down: async (queryInterface, Sequelize) => {
    return Promise.all([ 
      queryInterface.renameColumn(
        'Products',
        'photoContent',
        'photo'),
      queryInterface.removeColumn(
        'Products',
        'contentType'),
    ]);
  }
};
