'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.renameColumn(
        'users',
        'photo',
        'photoContent')
    ],
      queryInterface.addColumn(
        'users',
        'contentType',
        { type: Sequelize.STRING }, {
        after: 'photoContent' // after option is only supported by MySQL
     }),
   );
  },

  down: async (queryInterface, Sequelize) => {
    return Promise.all([ 
      queryInterface.renameColumn(
        'users',
        'photoContent',
        'photo'),
      queryInterface.removeColumn(
      'users',
      'contentType'
    ),
  ]);
  }
};


