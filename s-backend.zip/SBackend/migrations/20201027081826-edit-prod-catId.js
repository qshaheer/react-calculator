'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.renameColumn(
        'Products',
        'CatId',
        'CategoryId')
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.renameColumn(
        'Products',
        'CategoryId',
        'CatId')
      ]);
  }
};
