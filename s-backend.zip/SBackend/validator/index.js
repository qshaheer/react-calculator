const signUpValidator = (req, res, next) => {
    req.check('name', 'Name is required').notEmpty();
    req.check('email', 'Email must be between 3 to 32 characters')
    .matches(/.+\@.+\..+/)
    .withMessage('Email is invalid')
    .isLength({
      min: 4,
      max: 32
    });

    req.check('password', 'Password is required').notEmpty();
    req.check('password', 'Password must be between 4 to 32 characters').isLength({
      min: 4,
      max: 32
    });

    const errors = req.validationErrors();
    if (errors) {
        const firstError = errors.map(error => error.msg);
        return res.status(400).json({ error: firstError[0] });
    }
    next();
}
module.exports = {
    signUpValidator
}