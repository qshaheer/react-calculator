const { Router } = require('express');
const product = require('../controllers/product');
const category = require('../controllers/category');
const user = require('../controllers/user');
const { signUpValidator } = require('../validator');

const router = Router();

router.get('/', (req, res) => res.send('Welcome'));
router.get('/products', product.getAllProducts);
router.post('/products/create', product.createProduct);
router.get('/categories', category.getAllCategories);
router.post('/categories/create', category.createCategory);
router.post('/user/create', user.addUser);
router.post('/user/login', user.login);
router.post('/user/register', signUpValidator, user.register);

module.exports = router;