const express = require('express');
const routes = require('./routes');
const bodyParser = require('body-parser');
const expressValidator = require('express-validator');
let app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(expressValidator());
app.use("/api",routes);
app.listen(7000, () => {
    console.log('Success running 7000');
});
module.exports = app;