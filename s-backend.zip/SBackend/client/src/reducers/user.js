const userState = {
    fetching: false,
    user: {}
  };
  
  const user = (state = userState, action) => {
    switch (action.type) {
      case "REGISTER_USER_REQUEST":
        return {
          ...state,
        };
      case "REGISTER_USER_SUCCESS":
        return {
          ...state,
          user
        };
      case "REGISTER_USER_FAILED":
        return {
          ...state,
        };
      case "LOGIN_USER_REQUEST":
        return {
          ...state,
        };
      case "LOGIN_USER_SUCCESS":{
        const { data } = action.payload;
        if (data) {
          return {
            ...state,
            user: data
          };
        }
        else {
          return {
            ...state
          };
        }
      }
      case "LOGIN_USER_FAILED":
        return {
          ...state,
        };
      case "FIND_USER_REQUEST":
        return {
          ...state,
        };
      case "FIND_USER_SUCCESS":
        const { data } = action.payload;
        if (data) {
          return {
            ...state,
            user: data.user
          };
        }
        else {
          return {
            ...state
          };
        }
      case "FIND_USER_FAILED":
        return {
          ...state,
        };
        
      default:
        return state;
    }
  };
  
  export default user;