import { combineReducers } from 'redux';
import { reducer as forms } from 'redux-form';
import products from './products';
import users from './user';
import notification from './notification';
export default combineReducers({
 products,
 users,
 notification,
 form: forms
});