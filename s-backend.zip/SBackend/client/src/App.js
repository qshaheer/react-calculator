import React, {Component} from 'react';
import {connect} from 'react-redux';
import Products from './components/Products';
import Homepage from './components/Homepage';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import './App.css';
import './tailwind.output.css';
import { getUser } from './actions/user';
import Dashboard from './components/Dashboard';
import PrivateRoute from './Routes/PrivateRoute';


class App extends Component {
  state = {
    authToken: localStorage.getItem('loginToken'),
  };
  componentDidMount() {
    const { getUser } = this.props;
    const { authToken } = this.state;

    if (authToken) {
      getUser();
    }
  }
  render() {
    const { users } = this.props;
    console.log("===App.js user log====", users);
    const { user } = users;
    // console.log("**user_____id**", user._id);
    // console.log("====***ROUTE USER****=====", user);
    // console.log("===loginToken===", this.state.authToken);
    console.log("====user:", user);
    return (
      <>
        <Router>
          <Switch>
            <Route exact path="/" component={Homepage}/> :
            <PrivateRoute exact path="/products" component={Products} />
            <PrivateRoute exact path="/dashboard" component={Dashboard}/>
          </Switch>
        </Router>
        </>
    );
  }
}
const mapStateToProps = ({ users }) => ({ users });

const mapDispatchToProps = dispatch => ({
  getUser: () => dispatch(getUser())
});
export default connect(mapStateToProps, mapDispatchToProps)(App);
