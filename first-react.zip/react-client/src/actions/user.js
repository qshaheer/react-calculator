import { REGISTER_USER_REQUEST, REGISTER_USER_SUCCESS, REGISTER_USER_FAILED } from '../constants/usersActionTypes';
import axios from 'axios';
export const registerUser = (user) => (dispatch, getState) => {
    console.log("====user======", user);
  dispatch({
   type: REGISTER_USER_REQUEST
  });
  axios.post(
      '/api/user/register',
      {
        user
      }).then(({ data }) => {
      dispatch({ type: REGISTER_USER_SUCCESS, payload: data });
  });
 }