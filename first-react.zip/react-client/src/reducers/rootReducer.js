import { combineReducers } from 'redux';
import { reducer as forms } from 'redux-form';
import products from './products';
export default combineReducers({
 products, form: forms
});